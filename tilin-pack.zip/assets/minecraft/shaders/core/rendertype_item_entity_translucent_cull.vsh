#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;


out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

void main() {
    vec4 vista = ModelViewMat * vec4(Position, 1.0);
    // CrownFall weapon draw (CrownFallArmas): its parts, tinted 254 254 254, are placed for the hand's fixed
    // 70 degree view; their depth times tan(35)*ProjMat[1][1] lands them where the hand is at any field of view
    // (1 in the hand pass itself)
    if (all(greaterThan(Color.rgb, vec3(0.993))) && all(lessThan(Color.rgb, vec3(0.998)))) {
        vista.z *= 0.70020754 * ProjMat[1][1];
    }
    gl_Position = ProjMat * vista;

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
}
